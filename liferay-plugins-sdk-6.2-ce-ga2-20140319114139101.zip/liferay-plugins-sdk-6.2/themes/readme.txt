To view more information about developing themes, please view this wiki entry:

http://www.liferay.com/web/guest/community/wiki/-/wiki/Main/Themes#section-Themes-DevelopingATheme