import React from 'react';

import { Cards, Chart, CountryPicker } from './components';
import styles from './App.module.css';
import { fetchData, fetchDailyData } from './api';

import covidLogo from './images/image.png';
import covidLogoTitle from './images/Covid-19-Title.png';

class App extends React.Component {

    state = {
        data: {},
        dailyData: {},
        country: ''
    }

    async componentDidMount() {
        const fetchedData = await fetchData();
        const fetchedDailyData = await fetchDailyData();
        this.setState({
             data: fetchedData,
             dailyData: fetchedDailyData,
        });
    }

    handleCountryChange = async (country) => {
        const fetchedData = await fetchData(country);
        this.setState({
            data: fetchedData,
            country: country,
       });
    }

    render() {
        const { data, dailyData, country } = this.state;

        return (
        <div className={styles.container}>
            <img className={styles.image} src={covidLogoTitle} alt="COVID-19"/>
            <Cards data={data}></Cards>
            <CountryPicker handleCountryChange={this.handleCountryChange}></CountryPicker>
            <Chart dailyData={dailyData} data={data} country={country}></Chart>
        </div>);
    }
}

export default App;